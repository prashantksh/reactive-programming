package com.dailycodebuffer.reactiveprogramming;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactiveProgrammingTutorialApplicationTests {

	@Test
	void contextLoads() {
	}

}
